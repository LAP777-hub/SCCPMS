import { FormEvent, useMemo, useState } from 'react';
import {
  ArrowLeft,
  ArrowRight,
  BarChart3,
  Check,
  ChevronDown,
  GraduationCap,
  LockKeyhole,
  Mail,
  Pencil,
  ShieldCheck,
  Sparkles,
  UserRound,
  UsersRound,
} from 'lucide-react';

type Step = {
  number: number;
  title: string;
  shortTitle: string;
};

type FieldProps = {
  label: string;
  placeholder: string;
  icon: typeof UserRound;
  value: string;
  onChange: (value: string) => void;
  options?: string[];
  wide?: boolean;
};

const steps: Step[] = [
  { number: 1, title: 'Basic Personal Details', shortTitle: 'Personal' },
  { number: 2, title: 'Academic Identification', shortTitle: 'Academic' },
  { number: 3, title: 'Residence Details', shortTitle: 'Residence' },
  { number: 4, title: 'Next of Kin Details', shortTitle: 'Next of Kin' },
];

const fieldOptions = {
  category: ['College / University', 'Graduate School', 'Senior High School'],
  userType: ['Student', 'Lecturer', 'SPU Staff'],
  department: ['College of Nursing', 'College of Medicine', 'College of Business'],
  program: ['Bachelor of Science in Nursing', 'Doctor of Medicine', 'Business Administration'],
};

function Field({ label, placeholder, icon: Icon, value, onChange, options, wide = false }: FieldProps) {
  return (
    <label className={`field-group ${wide ? 'field-wide' : ''}`}>
      <span className="field-label">{label}</span>
      <span className="field-control">
        <Icon size={18} strokeWidth={1.7} />
        {options ? (
          <select value={value} onChange={(event) => onChange(event.target.value)}>
            <option value="" disabled>{placeholder}</option>
            {options.map((option) => <option key={option} value={option}>{option}</option>)}
          </select>
        ) : (
          <input value={value} onChange={(event) => onChange(event.target.value)} placeholder={placeholder} />
        )}
        {options && <ChevronDown className="select-chevron" size={18} strokeWidth={1.6} />}
      </span>
    </label>
  );
}

function App() {
  const [activeStep, setActiveStep] = useState(2);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [form, setForm] = useState({ category: '', userType: '', studentNumber: '', staffNumber: '', department: '', program: '', email: '' });

  const updateField = (field: keyof typeof form) => (value: string) => {
    setForm((current) => ({ ...current, [field]: value }));
  };

  const currentStep = steps[activeStep - 1];
  const isAcademicStep = activeStep === 2;
  const progress = useMemo(() => `${(activeStep / steps.length) * 100}%`, [activeStep]);

  const handleSubmit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (activeStep < steps.length) {
      setActiveStep((step) => step + 1);
      return;
    }
    setIsSubmitted(true);
  };

  return (
    <main className="portal-shell">
      <section className="brand-panel">
        <div className="brand-backdrop" />
        <div className="brand-content">
          <div className="brand-lockup">
            <div className="crest"><ShieldCheck size={48} strokeWidth={1.25} /><Sparkles className="crest-star" size={14} /></div>
            <div>
              <p className="brand-name">SCCPMS</p>
              <p className="brand-subtitle">SMART CAMPUS CLINIC<br />PATIENT MANAGEMENT SYSTEM</p>
            </div>
          </div>

          <div className="brand-message">
            <span className="eyebrow">St. Paul University Philippines</span>
            <h1>Care that moves<br /><em>with you.</em></h1>
            <p>One secure space for healthier campus communities and better patient experiences.</p>
          </div>

          <div className="benefits">
            <div className="benefit"><span className="benefit-icon"><ShieldCheck size={21} /></span><span><strong>Secure &amp; Reliable</strong><small>Your data is protected.</small></span></div>
            <div className="benefit"><span className="benefit-icon"><UsersRound size={21} /></span><span><strong>Streamlined Care</strong><small>Better patient experiences.</small></span></div>
            <div className="benefit"><span className="benefit-icon"><BarChart3 size={21} /></span><span><strong>Smart &amp; Efficient</strong><small>Smarter decisions.</small></span></div>
          </div>
        </div>
        <p className="copyright"><ShieldCheck size={14} /> © 2026 SCCPMS · St. Paul University Philippines. All rights reserved.</p>
      </section>

      <section className="form-panel">
        <div className="form-card">
          <div className="form-heading">
            <span className="mobile-kicker">ACCOUNT REGISTRATION</span>
            <h2>Create Your Account</h2>
            <p>Complete the steps below to register.</p>
          </div>

          <div className="stepper" aria-label="Registration progress">
            {steps.map((step, index) => (
              <div className={`step ${step.number === activeStep ? 'active' : ''} ${step.number < activeStep ? 'complete' : ''}`} key={step.number}>
                <div className="step-marker">{step.number < activeStep ? <Check size={19} /> : step.number}</div>
                <span>{step.title}</span>
                {index < steps.length - 1 && <div className="step-line" />}
              </div>
            ))}
          </div>

          {activeStep > 1 && (
            <div className="completed-banner">
              <span className="completed-icon"><Check size={19} /></span>
              <div><strong>Step {activeStep - 1} Completed</strong><p>Your details have been saved successfully.</p></div>
              <button type="button" className="edit-button" onClick={() => setActiveStep(activeStep - 1)}><Pencil size={14} /> Edit</button>
            </div>
          )}

          {isSubmitted ? (
            <div className="success-state"><span className="success-icon"><Check size={32} /></span><h3>Registration complete</h3><p>Your account request has been submitted. We’ll use <strong>{form.email || 'your email address'}</strong> for the next steps.</p><button className="primary-button" type="button" onClick={() => setIsSubmitted(false)}>Review details <ArrowRight size={19} /></button></div>
          ) : (
            <form onSubmit={handleSubmit}>
              <div className="section-heading"><span className="section-icon"><GraduationCap size={22} /></span><div><h3>{currentStep.title}</h3><p>{isAcademicStep ? 'Please provide your academic and institutional information.' : 'Please provide the information requested below.'}</p></div></div>

              {isAcademicStep ? <div className="fields-grid">
                <Field label="University Category" placeholder="Select category" icon={UserRound} value={form.category} onChange={updateField('category')} options={fieldOptions.category} />
                <Field label="Student/Lecturer/SPU Staff" placeholder="Select type" icon={UserRound} value={form.userType} onChange={updateField('userType')} options={fieldOptions.userType} />
                <Field label="Student Number" placeholder="Enter your student number" icon={UserRound} value={form.studentNumber} onChange={updateField('studentNumber')} />
                <Field label="Staff Number" placeholder="Enter your staff number" icon={UserRound} value={form.staffNumber} onChange={updateField('staffNumber')} />
                <Field label="Department / Faculty" placeholder="Select department or faculty" icon={GraduationCap} value={form.department} onChange={updateField('department')} options={fieldOptions.department} />
                <Field label="Program / Course" placeholder="Select program or course" icon={GraduationCap} value={form.program} onChange={updateField('program')} options={fieldOptions.program} />
                <Field label="Student Email" placeholder="Enter your official student email" icon={Mail} value={form.email} onChange={updateField('email')} wide />
              </div> : <div className="fields-grid">
                <Field label="First Name" placeholder="Enter your first name" icon={UserRound} value={form.studentNumber} onChange={updateField('studentNumber')} />
                <Field label="Last Name" placeholder="Enter your last name" icon={UserRound} value={form.staffNumber} onChange={updateField('staffNumber')} />
                <Field label="Email Address" placeholder="Enter your email address" icon={Mail} value={form.email} onChange={updateField('email')} wide />
              </div>}

              <div className="form-footer"><button className="secondary-button" type="button" onClick={() => setActiveStep((step) => Math.max(1, step - 1))} disabled={activeStep === 1}><ArrowLeft size={19} /> Previous Step</button><div className="footer-progress"><span>Step {activeStep} of {steps.length}</span><div className="mini-progress" style={{ '--progress': progress } as React.CSSProperties}><i /><i /><i /><i /></div></div><button className="primary-button" type="submit">{activeStep === steps.length ? 'Submit Registration' : 'Next Step'} <ArrowRight size={19} /></button></div>
            </form>
          )}

          <div className="privacy-note"><LockKeyhole size={14} /> Your information is safe and will only be used for authorized SCCPMS purposes.</div>
        </div>
      </section>
    </main>
  );
}

export default App;
